"""Entry-point guidance. See README.md for supported commands."""
from pathlib import Path
if __name__ == "__main__": print(Path(__file__).with_name("README.md").read_text())
