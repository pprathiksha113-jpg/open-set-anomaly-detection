import argparse, torch, numpy as np
from torch.utils.data import DataLoader
from src.data.dataset import MVTecDataset
from src.models.patchcore import PatchCore
from src.utils.metrics import image_auroc,pixel_auroc
def main():
 p=argparse.ArgumentParser(); p.add_argument("--data-root",default="data/raw/mvtec"); p.add_argument("--category",default="bottle"); p.add_argument("--bank",default="artifacts/memory_bank.pt"); p.add_argument("--batch-size",type=int,default=4); a=p.parse_args()
 model=PatchCore(device="cuda" if torch.cuda.is_available() else "cpu"); model.load(a.bank); loader=DataLoader(MVTecDataset(a.data_root,a.category,split="test"),batch_size=a.batch_size,shuffle=False,num_workers=0)
 scores=[]; labels=[]; maps=[]; masks=[]
 for b in loader:
  amap,score=model.predict(b["image"],out_size=256); scores.extend(score.numpy()); labels.extend(b["label"].numpy()); maps.extend(amap.numpy()); masks.extend(b["mask"].numpy())
 labels=np.asarray(labels); print("Images:",len(labels)); print("Image AUROC:",round(image_auroc(labels,np.asarray(scores)),4)); print("Pixel AUROC:",round(pixel_auroc(np.asarray(masks),np.asarray(maps)),4)); print("Choose thresholds using a separate normal calibration split, not this test set.")
if __name__=="__main__": main()
