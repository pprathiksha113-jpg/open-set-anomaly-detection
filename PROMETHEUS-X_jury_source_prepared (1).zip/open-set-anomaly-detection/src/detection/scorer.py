def threshold_decision(score, threshold):
    """Binary threshold decision: DEFECT above threshold, otherwise PASS."""
    return "DEFECT" if float(score) > float(threshold) else "PASS"
