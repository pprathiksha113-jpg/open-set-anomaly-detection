import torch
import torch.nn.functional as F
_M=torch.tensor([.485,.456,.406]).view(1,3,1,1); _S=torch.tensor([.229,.224,.225]).view(1,3,1,1)
def shift_batch(images,kind,strength=.5):
 """Synthetic brightness/contrast/blur/noise perturbation for controlled tests."""
 x=images.detach().clone(); m=_M.to(x.device); sd=_S.to(x.device); raw=(x*sd+m).clamp(0,1); q=float(max(0,min(1,strength)))
 if kind=="brightness": raw=(raw+.35*q).clamp(0,1)
 elif kind=="contrast":
  mu=raw.mean((2,3),keepdim=True); raw=((raw-mu)*(1+1.5*q)+mu).clamp(0,1)
 elif kind=="blur":
  k=3 if q<.34 else 5 if q<.67 else 7; raw=F.avg_pool2d(raw,k,stride=1,padding=k//2)
 elif kind=="noise": raw=(raw+torch.randn_like(raw)*(.08*q)).clamp(0,1)
 else: raise ValueError(f"Unsupported shift kind: {kind}")
 return (raw-m)/sd
