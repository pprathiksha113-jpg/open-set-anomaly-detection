import numpy as np
from src.calibration.calibrate import ConformalCalibrator,ece
from src.localization.heatmap import make_mask
from src.severity.severity import estimate_severity
def test_conformal_calibrator():
 c=ConformalCalibrator().fit([.1,.2,.3,.4]); assert c.threshold(.25)>=.3; assert 0<c.p_value(.9)[0]<1
def test_ece_perfect(): assert ece(np.array([0.,1.]),np.array([0,1]))==0
def test_mask_filters_small_components():
 a=np.zeros((20,20),dtype=np.float32); a[2:4,2:4]=1; a[10:16,10:16]=1; assert make_mask(a,.5,min_area=10).sum()==36
def test_empty_severity():
 r=estimate_severity(np.zeros((8,8)),np.zeros((8,8),dtype=np.uint8),.5); assert r["level"]=="none"
