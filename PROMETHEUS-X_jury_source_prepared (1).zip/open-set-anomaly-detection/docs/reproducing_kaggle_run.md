# Reproducing the Kaggle experiment
The reported experiment ran in Kaggle on a Tesla T4 using MVTec AD bottle. Team artifacts were `memory_bank.pt`, `threshold.json`, `baseline_stats_raw.npz`, `prometheus_final_results.json`, and `mvtec_validation_results.csv`. Export the executed notebook into `notebooks/` and copy matching inference artifacts into `artifacts/` if redistribution is permitted. Do not upload MVTec AD itself.

The clean scripts are reproducible entry points, but are not claimed to reproduce the historical run bit-for-bit. Preserve split indices, seeds, package versions, weights and calibration procedure before claiming exact reproducibility.
