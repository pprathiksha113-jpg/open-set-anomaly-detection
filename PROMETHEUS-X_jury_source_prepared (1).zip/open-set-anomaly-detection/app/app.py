
import sys
import os
import json
import time
import threading
import csv
from pathlib import Path
from datetime import datetime

import streamlit as st
import torch
import torch.nn.functional as F
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import cv2

from PIL import Image
import torchvision.transforms as T
from streamlit_webrtc import (
    webrtc_streamer,
    WebRtcMode,
    RTCConfiguration
)

# ============================================================
# CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="PROMETHEUS-X | Industrial Intelligence",
    page_icon="🔬",
    layout="wide",
    initial_sidebar_state="expanded"
)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.models.patchcore import PatchCore

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

ARTIFACTS_DIR = Path(os.environ.get("PROMETHEUS_ARTIFACTS", ROOT / "artifacts"))
BANK_PATH = Path(os.environ.get("PROMETHEUS_BANK", ARTIFACTS_DIR / "memory_bank.pt"))
THRESHOLD_PATH = Path(os.environ.get("PROMETHEUS_THRESHOLD", ARTIFACTS_DIR / "threshold.json"))
BASELINE_PATH = Path(os.environ.get("PROMETHEUS_BASELINE", ARTIFACTS_DIR / "baseline_stats_raw.npz"))
DATASET_ROOT = Path(os.environ.get("MVTEC_ROOT", ROOT / "data" / "raw" / "mvtec"))
HISTORY_PATH = Path(os.environ.get("PROMETHEUS_HISTORY", ROOT / "artifacts" / "inspection_history.csv"))

MEAN = [0.485, 0.456, 0.406]
STD = [0.229, 0.224, 0.225]

FEATURES = ["brightness", "contrast", "sharpness", "noise"]

TRANSFORM = T.Compose([
    T.Resize((256, 256)),
    T.ToTensor(),
    T.Normalize(MEAN, STD)
])

HISTORY_LOCK = threading.Lock()

# ============================================================
# PREMIUM INDUSTRIAL UI
# ============================================================

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Mono:wght@400;500&family=Inter:wght@400;500;600;700;800&display=swap');

:root {
    --bg: #080D17;
    --panel: #111A2A;
    --panel2: #151F31;
    --cyan: #38BDF8;
    --teal: #2DD4BF;
    --muted: #8B9BB4;
    --border: rgba(148,163,184,.15);
}

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.stApp {
    background:
      radial-gradient(ellipse at 75% 0%, rgba(14,165,233,.10), transparent 38%),
      linear-gradient(145deg, #080D17, #0B1220 60%, #080D17);
    color: #E5EDF7;
}

[data-testid="stSidebar"] {
    background: #0B1321;
    border-right: 1px solid var(--border);
}

[data-testid="stSidebar"] * {
    color: #DCE7F5;
}

.block-container {
    padding-top: 2rem;
    padding-bottom: 3rem;
    max-width: 1500px;
}

h1, h2, h3 {
    letter-spacing: -.04em;
}

.hero {
    padding: 25px 28px;
    border: 1px solid rgba(56,189,248,.25);
    border-radius: 18px;
    background:
      linear-gradient(110deg, rgba(14,165,233,.13), rgba(17,26,42,.96) 48%),
      #111A2A;
    margin-bottom: 22px;
}

.eyebrow {
    font-family: 'DM Mono', monospace;
    color: #38BDF8;
    font-size: 11px;
    letter-spacing: 2px;
    text-transform: uppercase;
}

.hero-title {
    font-size: clamp(30px, 4vw, 48px);
    font-weight: 800;
    letter-spacing: -2px;
    margin: 8px 0 2px;
    color: #F3F8FF;
}

.hero-sub {
    color: #9FB0C7;
    font-size: 14px;
}

.panel {
    background: linear-gradient(145deg, #141F31, #101827);
    border: 1px solid var(--border);
    border-radius: 15px;
    padding: 18px 20px;
    margin-bottom: 14px;
}

.panel-label {
    color: #8FA2BA;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    font-weight: 700;
}

.panel-value {
    color: #F3F8FF;
    font-size: 27px;
    font-weight: 800;
    margin-top: 8px;
    letter-spacing: -1px;
}

.panel-note {
    color: #8192AA;
    font-size: 12px;
    margin-top: 4px;
}

.status-dot {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #2DD4BF;
    box-shadow: 0 0 12px #2DD4BF;
    margin-right: 8px;
}

.mono {
    font-family: 'DM Mono', monospace;
}

div[data-testid="stMetric"] {
    background: #111A2A;
    border: 1px solid var(--border);
    padding: 15px 17px;
    border-radius: 13px;
}

div[data-testid="stMetricLabel"] {
    color: #91A4BD;
}

div[data-testid="stMetricValue"] {
    color: #F1F7FF;
}

.stButton button {
    border-radius: 9px;
    border: 1px solid rgba(56,189,248,.35);
    background: rgba(14,165,233,.13);
    color: #BAE6FD;
    font-weight: 700;
}

.stButton button:hover {
    border-color: #38BDF8;
    background: rgba(14,165,233,.25);
    color: white;
}

div[data-testid="stFileUploader"] {
    background: #111A2A;
    border: 1px dashed rgba(56,189,248,.4);
    border-radius: 14px;
    padding: 12px;
}

hr {
    border-color: rgba(148,163,184,.15);
}

footer {
    visibility: hidden;
}

#MainMenu {
    visibility: hidden;
}

</style>
""", unsafe_allow_html=True)


def hero(section, subtitle):
    st.markdown(f"""
    <div class="hero">
        <div class="eyebrow">PROMETHEUS-X / INDUSTRIAL INTELLIGENCE</div>
        <div class="hero-title">{section}</div>
        <div class="hero-sub">{subtitle}</div>
    </div>
    """, unsafe_allow_html=True)


def metric_card(label, value, note=""):
    st.markdown(f"""
    <div class="panel">
        <div class="panel-label">{label}</div>
        <div class="panel-value">{value}</div>
        <div class="panel-note">{note}</div>
    </div>
    """, unsafe_allow_html=True)


def status_color(decision):
    return {
        "PASS": "#2DD4BF",
        "DEFECT": "#FB7185",
        "REVIEW": "#FBBF24"
    }.get(decision, "#94A3B8")


# ============================================================
# MODEL LOADING
# ============================================================

@st.cache_resource
def load_model():

    required = [
        BANK_PATH,
        THRESHOLD_PATH,
        BASELINE_PATH
    ]

    missing = [str(p) for p in required if not p.exists()]

    if missing:
        raise FileNotFoundError(
            "Missing model assets: " + ", ".join(missing)
        )

    model = PatchCore(
        coreset_ratio=0.005,
        k=3,
        device=DEVICE
    )

    model.load(str(BANK_PATH))
    model.extractor.eval()

    with open(THRESHOLD_PATH) as f:
        calibrated_threshold = float(json.load(f)["threshold"])

    baseline_file = np.load(BASELINE_PATH)

    baseline = {
        "mean": baseline_file["mean"].astype(np.float64),
        "std": baseline_file["std"].astype(np.float64)
    }

    if len(baseline["mean"]) != 4 or len(baseline["std"]) != 4:
        raise ValueError("Baseline must contain four feature statistics.")

    return model, calibrated_threshold, baseline


try:
    model, threshold, baseline = load_model()
    MODEL_READY = True
    MODEL_ERROR = None
except Exception as exc:
    MODEL_READY = False
    MODEL_ERROR = str(exc)
    model = None
    threshold = None
    baseline = None


# ============================================================
# INSPECTION HISTORY
# ============================================================

HISTORY_COLUMNS = [
    "timestamp",
    "source",
    "decision",
    "score",
    "threshold",
    "reason"
]


def log_inspection(source, decision, score, reason):

    row = {
        "timestamp": datetime.now().isoformat(timespec="seconds"),
        "source": source,
        "decision": decision,
        "score": float(score),
        "threshold": float(threshold),
        "reason": reason
    }

    with HISTORY_LOCK:
        file_exists = HISTORY_PATH.exists()

        with open(HISTORY_PATH, "a", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=HISTORY_COLUMNS
            )

            if not file_exists:
                writer.writeheader()

            writer.writerow(row)


def load_history():

    if not HISTORY_PATH.exists():
        return pd.DataFrame(columns=HISTORY_COLUMNS)

    try:
        df = pd.read_csv(HISTORY_PATH)
        if not df.empty:
            df["timestamp"] = pd.to_datetime(
                df["timestamp"],
                errors="coerce"
            )
            df["score"] = pd.to_numeric(
                df["score"],
                errors="coerce"
            )
        return df
    except Exception:
        return pd.DataFrame(columns=HISTORY_COLUMNS)


# ============================================================
# DISTRIBUTION SHIFT SCREENING
# Must match baseline calculation exactly.
# ============================================================

def extract_statistics(images):

    mean = torch.tensor(
        MEAN, device=images.device
    ).view(1, 3, 1, 1)

    std = torch.tensor(
        STD, device=images.device
    ).view(1, 3, 1, 1)

    raw = (images * std + mean).clamp(0, 1)
    gray = raw.mean(dim=1)

    brightness = gray.mean(dim=(1, 2))
    contrast = gray.std(dim=(1, 2))

    # Same vertical-difference formula used to build baseline_stats_raw.npz
    sharpness = (
        gray[:, 1:, :] - gray[:, :-1, :]
    ).abs().mean(dim=(1, 2))

    # Same horizontal-difference formula used to build baseline_stats_raw.npz
    noise = (
        gray[:, :, 1:] - gray[:, :, :-1]
    ).abs().mean(dim=(1, 2))

    values = torch.stack(
        [brightness, contrast, sharpness, noise],
        dim=1
    ).detach().cpu().numpy()[0]

    return dict(zip(FEATURES, values.tolist()))


def check_shift(stats):

    shifted = []

    for index, feature in enumerate(FEATURES):

        ref_mean = float(baseline["mean"][index])
        ref_std = max(float(baseline["std"][index]), 1e-8)

        value = float(stats[feature])

        if abs(value - ref_mean) > 3 * ref_std:
            shifted.append(feature)

    return shifted


# ============================================================
# COMMON INFERENCE
# ============================================================

def inspect_image(pil_image):

    image = pil_image.convert("RGB")
    tensor = TRANSFORM(image).unsqueeze(0).to(DEVICE)

    with torch.inference_mode():
        maps, scores = model.predict(
            tensor,
            out_size=256
        )

    score = float(scores[0])
    anomaly_map = maps[0].detach().cpu().numpy()

    stats = extract_statistics(tensor)
    shifted = check_shift(stats)

    if shifted:
        decision = "REVIEW"
        reason = "Image conditions differ from calibration baseline"

    elif score > threshold:
        decision = "DEFECT"
        reason = "Anomaly score exceeds calibrated threshold"

    else:
        decision = "PASS"
        reason = "No anomaly detected above calibrated threshold"

    return score, anomaly_map, decision, reason, shifted


def make_overlay(pil_image, anomaly_map):

    rgb = np.array(pil_image.convert("RGB").resize((256, 256)))

    heat = np.uint8(
        255 * (
            anomaly_map - anomaly_map.min()
        ) / (
            anomaly_map.max() - anomaly_map.min() + 1e-8
        )
    )

    heat_color = cv2.applyColorMap(
        heat,
        cv2.COLORMAP_JET
    )

    heat_color = cv2.cvtColor(
        heat_color,
        cv2.COLOR_BGR2RGB
    )

    overlay = cv2.addWeighted(
        rgb,
        0.62,
        heat_color,
        0.38,
        0
    )

    return overlay, heat


# ============================================================
# LIVE CAMERA PROCESSOR
# ============================================================

class LiveInspectionProcessor:

    def __init__(self):

        self.last_result = None
        self.last_processed = 0.0
        self.last_logged = 0.0
        self.lock = threading.Lock()

    def recv(self, frame):

        bgr = frame.to_ndarray(format="bgr24")
        now = time.time()

        if now - self.last_processed >= 0.5:

            self.last_processed = now

            rgb = cv2.cvtColor(
                bgr,
                cv2.COLOR_BGR2RGB
            )

            image = Image.fromarray(rgb)

            try:

                score, amap, decision, reason, shifted = (
                    inspect_image(image)
                )

                heat = np.uint8(
                    255 * (
                        amap - amap.min()
                    ) / (
                        amap.max() - amap.min() + 1e-8
                    )
                )

                heat = cv2.applyColorMap(
                    heat,
                    cv2.COLORMAP_JET
                )

                heat = cv2.resize(
                    heat,
                    (bgr.shape[1], bgr.shape[0])
                )

                overlay = cv2.addWeighted(
                    bgr,
                    0.65,
                    heat,
                    0.35,
                    0
                )

                color = {
                    "PASS": (45, 190, 150),
                    "DEFECT": (70, 70, 245),
                    "REVIEW": (0, 180, 255)
                }[decision]

                cv2.rectangle(
                    overlay,
                    (10, 10),
                    (overlay.shape[1] - 10, 85),
                    color,
                    2
                )

                cv2.putText(
                    overlay,
                    f"{decision} | Score: {score:.3f}",
                    (20, 48),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.8,
                    color,
                    2
                )

                with self.lock:
                    self.last_result = {
                        "score": score,
                        "decision": decision,
                        "reason": reason,
                        "shifted": shifted,
                        "frame": overlay.copy(),
                        "time": now
                    }

                # Avoid recording every processed video frame.
                if now - self.last_logged >= 5:
                    log_inspection(
                        "Live camera",
                        decision,
                        score,
                        reason
                    )
                    self.last_logged = now

                return frame.from_ndarray(
                    overlay,
                    format="bgr24"
                )

            except Exception as exc:

                with self.lock:
                    self.last_result = {
                        "error": str(exc)
                    }

        # Keep the latest processed overlay on intervening frames.
        with self.lock:
            current = self.last_result

        if current and "frame" in current:
            return frame.from_ndarray(
                current["frame"],
                format="bgr24"
            )

        return frame


# ============================================================
# SIDEBAR / NAVIGATION
# ============================================================

with st.sidebar:

    st.markdown("""
    <div style="padding:8px 2px 20px">
      <div style="font-size:12px;letter-spacing:3px;color:#38BDF8;font-weight:800">
        P R O M E T H E U S
      </div>
      <div style="font-size:27px;font-weight:800;color:#F3F8FF">
        X<span style="color:#38BDF8">.</span>
      </div>
      <div style="font-size:10px;color:#8192AA;letter-spacing:1.5px">
        INDUSTRIAL INTELLIGENCE
      </div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("---")

    page = st.radio(
        "NAVIGATION",
        [
            "Overview",
            "Image Analysis",
            "Live Inspection",
            "Dataset Explorer",
            "Analytics",
            "System Monitor"
        ],
        label_visibility="visible"
    )

    st.markdown("---")

    if MODEL_READY:
        st.markdown(
            '<span class="status-dot"></span> MODEL ONLINE',
            unsafe_allow_html=True
        )
    else:
        st.error("MODEL OFFLINE")

    st.caption(f"Compute: {DEVICE.upper()}")
    st.caption("Prototype build | A06")


# ============================================================
# MODEL ERROR GUARD
# ============================================================

if not MODEL_READY:

    hero("SYSTEM UNAVAILABLE", "Model assets could not be loaded")

    st.error(MODEL_ERROR)

    st.info(
        "Check that the memory bank, threshold JSON, "
        "baseline file and repository are present."
    )

    st.stop()


# ============================================================
# OVERVIEW
# ============================================================

if page == "Overview":

    hero(
        "Industrial Command Center",
        "Open-set anomaly detection • Visual inspection • Distribution-shift screening"
    )

    history = load_history()

    total = len(history)

    if total:
        passed = int((history["decision"] == "PASS").sum())
        defects = int((history["decision"] == "DEFECT").sum())
        reviews = int((history["decision"] == "REVIEW").sum())
        latest_score = float(history.iloc[-1]["score"])
    else:
        passed = defects = reviews = 0
        latest_score = 0.0

    cols = st.columns(4)

    with cols[0]:
        metric_card("Total inspections", total, "Recorded inspection events")

    with cols[1]:
        metric_card("PASS", passed, "Normal decisions")

    with cols[2]:
        metric_card("DEFECT", defects, "Anomaly decisions")

    with cols[3]:
        metric_card("REVIEW", reviews, "Distribution-shift flags")

    st.markdown("### System status")

    left, right = st.columns([1.35, 1])

    with left:
        st.markdown('<div class="panel">', unsafe_allow_html=True)
        st.markdown("**INSPECTION ENGINE**")
        st.markdown(
            '<span class="status-dot"></span> PatchCore model loaded',
            unsafe_allow_html=True
        )
        st.markdown(
            '<span class="status-dot"></span> Memory bank available',
            unsafe_allow_html=True
        )
        st.markdown(
            '<span class="status-dot"></span> Calibration threshold loaded',
            unsafe_allow_html=True
        )
        st.markdown(
            '<span class="status-dot"></span> Distribution baseline loaded',
            unsafe_allow_html=True
        )
        st.markdown("</div>", unsafe_allow_html=True)

    with right:
        metric_card(
            "Latest anomaly score",
            f"{latest_score:.4f}" if total else "—",
            f"Decision threshold: {threshold:.4f}"
        )

    st.markdown("### Recent inspections")

    if total:
        recent = history.tail(8).iloc[::-1]
        st.dataframe(
            recent[
                ["timestamp", "source", "decision", "score"]
            ],
            use_container_width=True,
            hide_index=True
        )
    else:
        st.info(
            "No inspection records yet. Start with Image Analysis "
            "or Live Inspection."
        )

    st.caption(
        "Research prototype. Historical figures reflect only inspections "
        "recorded by this dashboard."
    )


# ============================================================
# IMAGE ANALYSIS
# ============================================================

elif page == "Image Analysis":

    hero(
        "Image Analysis",
        "Inspect an industrial product image and visualize anomalous regions"
    )

    uploaded = st.file_uploader(
        "Upload product image",
        type=["png", "jpg", "jpeg", "bmp"],
        key="analysis_upload"
    )

    if uploaded:

        image = Image.open(uploaded).convert("RGB")

        with st.spinner("Running PatchCore inspection..."):
            score, amap, decision, reason, shifted = inspect_image(image)

        signature = (
            uploaded.name,
            uploaded.size,
            round(score, 7),
            decision
        )

        if st.session_state.get("last_upload_signature") != signature:

            log_inspection(
                "Image upload",
                decision,
                score,
                reason
            )

            st.session_state["last_upload_signature"] = signature

        st.markdown("### Inspection result")

        c1, c2, c3 = st.columns(3)

        c1.metric("Anomaly score", f"{score:.4f}")
        c2.metric("Calibrated threshold", f"{threshold:.4f}")
        c3.metric("Decision", decision)

        if decision == "PASS":
            st.success(reason)
        elif decision == "DEFECT":
            st.error(reason)
        else:
            st.warning(reason)

        if shifted:
            st.warning(
                "Distribution-shift indicators: " + ", ".join(shifted)
            )

        overlay, heat = make_overlay(image, amap)

        col1, col2 = st.columns(2)

        with col1:
            st.markdown("**ORIGINAL IMAGE**")
            st.image(
                image,
                use_container_width=True
            )

        with col2:
            st.markdown("**ANOMALY HEATMAP OVERLAY**")
            st.image(
                overlay,
                use_container_width=True
            )

        with st.expander("Inspection details"):
            st.write("Decision rationale:", reason)
            st.write("Anomaly score:", score)
            st.write("Threshold:", threshold)
            st.write("Shifted features:", shifted if shifted else "None detected")

            st.caption(
                "Anomaly scores are model scores, not probabilities. "
                "A heatmap highlights relative anomaly intensity."
            )

    else:
        st.info(
            "Upload a product image to begin inspection."
        )

        metric_card(
            "Inspection pipeline",
            "READY",
            "PatchCore • WideResNet50-2 • 256 × 256 input"
        )


# ============================================================
# LIVE INSPECTION
# ============================================================

elif page == "Live Inspection":

    hero(
        "Live Camera Inspection",
        "Continuous browser-camera inspection with anomaly visualization"
    )

    st.info(
        "Allow camera permission when prompted. "
        "The inspection processor analyzes approximately two frames per second."
    )

    rtc_configuration = RTCConfiguration({
        "iceServers": [
            {"urls": ["stun:stun.l.google.com:19302"]}
        ]
    })

    ctx = webrtc_streamer(
        key="prometheus-live-camera",
        mode=WebRtcMode.SENDRECV,
        rtc_configuration=rtc_configuration,
        media_stream_constraints={
            "video": True,
            "audio": False
        },
        video_processor_factory=LiveInspectionProcessor,
        async_processing=True
    )

    st.markdown("### Latest inspection")

    @st.fragment(run_every="1s")
    def live_metrics():

        if ctx.video_processor:

            with ctx.video_processor.lock:
                result = ctx.video_processor.last_result

            if result:

                if "error" in result:
                    st.error(result["error"])
                else:
                    a, b, c = st.columns(3)

                    a.metric(
                        "Anomaly score",
                        f"{result['score']:.4f}"
                    )

                    b.metric(
                        "Decision",
                        result["decision"]
                    )

                    c.metric(
                        "Threshold",
                        f"{threshold:.4f}"
                    )

                    if result["decision"] == "PASS":
                        st.success(result["reason"])
                    elif result["decision"] == "DEFECT":
                        st.error(result["reason"])
                    else:
                        st.warning(result["reason"])

                    if result["shifted"]:
                        st.caption(
                            "Shifted features: "
                            + ", ".join(result["shifted"])
                        )

            else:
                st.info("Waiting for the first processed frame...")

        else:
            st.info("Start the camera using the START button.")

    live_metrics()

    st.caption(
        "Live decisions are screening outputs. Confirm defects through "
        "appropriate quality-control procedures."
    )



# ============================================================
# DATASET EXPLORER
# ============================================================

elif page == "Dataset Explorer":

    hero(
        "MVTec AD Dataset Explorer",
        "Explore real industrial samples, defect masks and model predictions"
    )

    test_root = DATASET_ROOT / "bottle" / "test"
    mask_root = DATASET_ROOT / "bottle" / "ground_truth"

    categories = [
        "good", "broken_large", "broken_small", "contamination"
    ]

    if not test_root.exists():
        st.error(f"Dataset not found: {test_root}")
        st.stop()

    st.markdown("### Dataset overview")

    cols = st.columns(4)

    for col, category in zip(cols, categories):
        count = len(list((test_root / category).glob("*.png")))
        with col:
            metric_card(category.replace("_", " ").title(), count,
                        "MVTec AD test images")

    st.markdown("### Browse dataset samples")

    selected_category = st.selectbox(
        "Defect category",
        categories
    )

    sample_paths = sorted(
        (test_root / selected_category).glob("*.png")
    )

    if sample_paths:

        selected_name = st.selectbox(
            "Select image",
            [p.name for p in sample_paths]
        )

        selected_path = test_root / selected_category / selected_name
        sample_image = Image.open(selected_path).convert("RGB")

        with st.spinner("Running PatchCore..."):
            score, amap, decision, reason, shifted = inspect_image(
                sample_image
            )

        overlay, _ = make_overlay(sample_image, amap)

        a, b, c = st.columns(3)
        a.metric("Anomaly score", f"{score:.4f}")
        b.metric("Threshold", f"{threshold:.4f}")
        c.metric("Prediction", decision)

        if decision == "PASS":
            st.success(reason)
        elif decision == "DEFECT":
            st.error(reason)
        else:
            st.warning(reason)

        if shifted:
            st.warning("Shift indicators: " + ", ".join(shifted))

        col1, col2, col3 = st.columns(3)

        with col1:
            st.markdown("**Original image**")
            st.image(sample_image, use_container_width=True)

        with col2:
            st.markdown("**Ground-truth mask**")

            if selected_category == "good":
                st.image(
                    np.zeros((256, 256), dtype=np.uint8),
                    caption="Normal — no defect mask",
                    use_container_width=True
                )
            else:
                mask_path = (
                    mask_root / selected_category /
                    f"{selected_path.stem}_mask.png"
                )

                if mask_path.exists():
                    mask = Image.open(mask_path).convert("L")
                    st.image(mask, use_container_width=True)
                else:
                    st.warning("Ground-truth mask unavailable.")

        with col3:
            st.markdown("**PatchCore prediction**")
            st.image(overlay, use_container_width=True)

        st.caption(
            "Ground-truth masks are dataset annotations; "
            "anomaly heatmaps are model predictions."
        )

    else:
        st.warning("No images found in this category.")


# ============================================================
# ANALYTICS
# ============================================================

elif page == "Analytics":

    hero(
        "Inspection Analytics",
        "Explore recorded inspection outcomes and anomaly-score trends"
    )

    history = load_history()

    if history.empty:

        st.info(
            "Analytics will appear after you perform image or live inspections."
        )

    else:

        a, b, c = st.columns(3)

        a.metric("Recorded inspections", len(history))
        b.metric(
            "Average anomaly score",
            f"{history['score'].mean():.4f}"
        )
        c.metric(
            "Highest anomaly score",
            f"{history['score'].max():.4f}"
        )

        st.markdown("### Decision distribution")

        counts = (
            history["decision"]
            .value_counts()
            .reindex(["PASS", "DEFECT", "REVIEW"], fill_value=0)
            .rename_axis("Decision")
            .reset_index(name="Count")
        )

        fig = px.pie(
            counts,
            names="Decision",
            values="Count",
            hole=0.62,
            title="Recorded inspection outcomes"
        )

        fig.update_layout(
            template="plotly_dark",
            paper_bgcolor="rgba(0,0,0,0)",
            plot_bgcolor="rgba(0,0,0,0)",
            legend_title=""
        )

        st.plotly_chart(fig, use_container_width=True)

        st.markdown("### Anomaly score trend")

        trend = history.dropna(subset=["timestamp", "score"]).copy()

        if not trend.empty:

            fig2 = px.scatter(
                trend,
                x="timestamp",
                y="score",
                color="decision",
                symbol="source",
                hover_data=["reason"],
                title="Inspection score history"
            )

            fig2.add_hline(
                y=threshold,
                line_dash="dash",
                line_color="#FBBF24",
                annotation_text="Calibrated threshold"
            )

            fig2.update_layout(
                template="plotly_dark",
                paper_bgcolor="rgba(0,0,0,0)",
                plot_bgcolor="rgba(0,0,0,0)",
                xaxis_title="Inspection time",
                yaxis_title="Anomaly score"
            )

            st.plotly_chart(fig2, use_container_width=True)

        st.markdown("### Inspection log")

        st.dataframe(
            history.sort_values(
                "timestamp",
                ascending=False
            ),
            use_container_width=True,
            hide_index=True
        )

        csv_data = history.to_csv(index=False).encode("utf-8")

        st.download_button(
            "Download inspection history CSV",
            data=csv_data,
            file_name="prometheus_x_inspection_history.csv",
            mime="text/csv"
        )


# ============================================================
# SYSTEM MONITOR
# ============================================================

elif page == "System Monitor":

    hero(
        "System Monitor",
        "Runtime environment, model configuration and calibration details"
    )

    c1, c2, c3 = st.columns(3)

    c1.metric("Compute device", DEVICE.upper())

    if torch.cuda.is_available():
        gpu_name = torch.cuda.get_device_name(0)
        gpu_memory = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
        c2.metric("GPU", gpu_name)
        c3.metric("GPU memory", f"{gpu_memory:.1f} GB")
    else:
        c2.metric("GPU", "Not available")
        c3.metric("GPU memory", "—")

    st.markdown("### Model configuration")

    config = pd.DataFrame({
        "Parameter": [
            "Architecture",
            "Feature extractor",
            "Input resolution",
            "Coreset ratio",
            "Nearest neighbours (k)",
            "Memory bank",
            "Decision threshold"
        ],
        "Value": [
            "PatchCore",
            "WideResNet50-2",
            "256 × 256",
            "0.005",
            "3",
            "855 × 1536 (calibrated model)",
            f"{threshold:.6f}"
        ]
    })

    st.dataframe(
        config,
        use_container_width=True,
        hide_index=True
    )

    st.markdown("### Distribution reference")

    baseline_table = pd.DataFrame({
        "Feature": FEATURES,
        "Calibration mean": baseline["mean"],
        "Calibration std": baseline["std"]
    })

    st.dataframe(
        baseline_table,
        use_container_width=True,
        hide_index=True
    )

    st.markdown("### Runtime")

    st.write("PyTorch version:", torch.__version__)
    st.write("CUDA available:", torch.cuda.is_available())
    st.write("Inspection history:", str(HISTORY_PATH))
    st.write("Model bank:", str(BANK_PATH))

    st.caption(
        "The system monitor reports configured model details and runtime "
        "availability. It does not represent a certified production monitor."
    )


# ============================================================
# FOOTER
# ============================================================

st.markdown("---")

st.markdown("""
<div style="text-align:center;padding:10px;color:#71839C">
  <span style="font-family:'DM Mono',monospace;letter-spacing:2px">
    PROMETHEUS-X
  </span>
  <br>
  <span style="font-size:11px">
    OPEN-SET INDUSTRIAL ANOMALY DETECTION • RESEARCH PROTOTYPE
  </span>
</div>
""", unsafe_allow_html=True)
