import argparse
from pathlib import Path
import torch
from torch.utils.data import DataLoader, Subset
from src.data.dataset import MVTecDataset
from src.models.patchcore import PatchCore
def main():
 p=argparse.ArgumentParser(description="Build PatchCore memory bank from normal MVTec training images")
 p.add_argument("--data-root",default="data/raw/mvtec"); p.add_argument("--category",default="bottle"); p.add_argument("--image-size",type=int,default=256); p.add_argument("--coreset-ratio",type=float,default=0.005); p.add_argument("--k",type=int,default=3); p.add_argument("--batch-size",type=int,default=8); p.add_argument("--max-train-images",type=int,default=0); p.add_argument("--output",default="artifacts/memory_bank.pt")
 a=p.parse_args(); ds=MVTecDataset(a.data_root,a.category,split="train",image_size=a.image_size)
 if not len(ds): raise SystemExit(f"No normal training images found under {a.data_root}/{a.category}/train/good")
 if a.max_train_images: ds=Subset(ds,range(min(a.max_train_images,len(ds))))
 loader=DataLoader(ds,batch_size=a.batch_size,shuffle=False,num_workers=0); device="cuda" if torch.cuda.is_available() else "cpu"
 model=PatchCore(coreset_ratio=a.coreset_ratio,k=a.k,device=device); model.fit(loader); out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); model.save(out)
 print(f"Saved {out.resolve()} | device={device} | bank={tuple(model.bank.shape)}")
if __name__=="__main__": main()
